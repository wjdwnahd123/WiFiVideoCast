package kr.local.wifivideocast
data class DlnaDevice(val name: String, val controlUrl: String, val serviceType: String)
