package kr.local.wifivideocast

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.net.*
import javax.xml.parsers.DocumentBuilderFactory

class DlnaClient(private val context: Context) {
 suspend fun discover(): List<DlnaDevice> = withContext(Dispatchers.IO) {
  val results = linkedMapOf<String, DlnaDevice>()
  val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
  val lock = wifi.createMulticastLock("VideoCastSSDP")
  try {
   lock.acquire()
   DatagramSocket().use { socket ->
    socket.soTimeout = 400
    val query = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n").toByteArray()
    socket.send(DatagramPacket(query, query.size, InetAddress.getByName("239.255.255.250"), 1900))
    val deadline = System.currentTimeMillis() + 3500
    while (System.currentTimeMillis() < deadline) {
     try {
      val buf = ByteArray(8192); val packet = DatagramPacket(buf, buf.size); socket.receive(packet)
      val response = String(packet.data, 0, packet.length)
      val loc = Regex("(?im)^LOCATION:\\s*(.+)$").find(response)?.groupValues?.get(1)?.trim()
      if (loc != null && !results.containsKey(loc)) parse(loc)?.let { results[loc] = it }
     } catch (_: SocketTimeoutException) {}
    }
   }
  } finally { if (lock.isHeld) lock.release() }
  results.values.toList()
 }
 private fun parse(location: String): DlnaDevice? = try {
  val c = URL(location).openConnection() as HttpURLConnection
  c.connectTimeout = 2500; c.readTimeout = 2500
  val bytes = c.inputStream.use { it.readBytes() }; c.disconnect()
  val f = DocumentBuilderFactory.newInstance()
  f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
  val doc = f.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
  val services = doc.getElementsByTagName("service")
  var control: String? = null
  var type = "urn:schemas-upnp-org:service:AVTransport:1"
  for (i in 0 until services.length) {
   val e = services.item(i) as Element
   val t = e.getElementsByTagName("serviceType").item(0)?.textContent ?: continue
   if (t.contains("AVTransport")) {
    type = t; control = e.getElementsByTagName("controlURL").item(0)?.textContent; break
   }
  }
  if (control.isNullOrBlank()) null else {
   val name = doc.getElementsByTagName("friendlyName").item(0)?.textContent ?: "DLNA TV"
   DlnaDevice(name, URL(URL(location), control).toString(), type)
  }
 } catch (_: Exception) { null }

 suspend fun play(d: DlnaDevice, mediaUrl: String, title: String) = withContext(Dispatchers.IO) {
  val mime = if (mediaUrl.contains(".m3u8", true)) "application/vnd.apple.mpegurl" else if (mediaUrl.contains(".webm", true)) "video/webm" else "video/mp4"
  val meta = "<DIDL-Lite xmlns=\\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\\" xmlns:dc=\\"http://purl.org/dc/elements/1.1/\\" xmlns:upnp=\\"urn:schemas-upnp-org:metadata-1-0/upnp/\\"><item id=\\"0\\" parentID=\\"-1\\" restricted=\\"1\\"><dc:title>${esc(title)}</dc:title><upnp:class>object.item.videoItem</upnp:class><res protocolInfo=\\"http-get:*:$mime:*\\">${esc(mediaUrl)}</res></item></DIDL-Lite>"
  val args = "<InstanceID>0</InstanceID><CurrentURI>${esc(mediaUrl)}</CurrentURI><CurrentURIMetaData>${esc(meta)}</CurrentURIMetaData>"
  soap(d, "SetAVTransportURI", args); soap(d, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>")
 }
 suspend fun pause(d: DlnaDevice) = withContext(Dispatchers.IO) { soap(d, "Pause", "<InstanceID>0</InstanceID>") }
 suspend fun stop(d: DlnaDevice) = withContext(Dispatchers.IO) { soap(d, "Stop", "<InstanceID>0</InstanceID>") }

 private fun soap(d: DlnaDevice, action: String, args: String) {
  val body = "<?xml version=\\"1.0\\"?><s:Envelope xmlns:s=\\"http://schemas.xmlsoap.org/soap/envelope/\\" s:encodingStyle=\\"http://schemas.xmlsoap.org/soap/encoding/\\"><s:Body><u:$action xmlns:u=\\"${d.serviceType}\\">$args</u:$action></s:Body></s:Envelope>"
  val c = URL(d.controlUrl).openConnection() as HttpURLConnection
  c.requestMethod = "POST"; c.connectTimeout = 5000; c.readTimeout = 5000; c.doOutput = true
  c.setRequestProperty("Content-Type", "text/xml; charset=\\"utf-8\\"")
  c.setRequestProperty("SOAPAction", "\\"${d.serviceType}#$action\\"")
  c.outputStream.use { it.write(body.toByteArray()) }
  val code = c.responseCode
  if (code !in 200..299) throw IllegalStateException("TV 응답 HTTP $code")
  c.inputStream.close(); c.disconnect()
 }
 private fun esc(s: String) = s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\\"","&quot;").replace("'","&apos;")
}
