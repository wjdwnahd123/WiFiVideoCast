# Wi-Fi Video Cast 1.0 — Android source project

## 구현
- 앱 내부 브라우저(WebView)
- 브라우저의 HTML5 video/audio/source 및 일부 네트워크 리소스에서 미디어 URL 후보 수집
- Android 공유 메뉴의 URL 수신
- Chromecast 기본 미디어 수신기로 직접 URL 전송
- DLNA/UPnP TV 검색, 재생, 일시정지, 중지
- TV가 직접 스트림을 재생하므로 호환되는 스트림이면 휴대폰 화면을 끄고도 재생 지속 가능

## 빌드
Android Studio에서 폴더를 열고 Gradle Sync 후 Android 기기에 설치하세요. Android SDK 35 필요.
두 기기를 같은 Wi-Fi에 연결해야 합니다. Chromecast 연결은 화면의 Cast 경로 버튼, DLNA는 TV 검색에서 선택합니다.

## 현실적인 제한
- APK/실기기 검증본이 아닌 Android Studio 소스 프로젝트입니다.
- 임의 웹사이트의 동영상을 전부 추출할 수는 없습니다. 웹페이지의 HTML5 미디어 URL 또는 파일 확장자가 노출된 네트워크 요청만 후보로 잡습니다.
- DRM, 로그인 쿠키, Referer, 서명 토큰, 암호화된 DASH/HLS, 브라우저 내부 디코딩만 가능한 스트림은 송출되지 않을 수 있습니다.
- 외부 Chrome 앱의 재생 내부 상태를 다른 앱이 읽을 수는 없습니다. 외부 브라우저에서는 공유 메뉴로 링크를 전달할 수 있지만, 영상 URL 추출은 앱 내 브라우저에서 해야 합니다.
- TV는 Chromecast 수신기 또는 DLNA MediaRenderer를 지원해야 합니다. 모든 TV 호환을 보장하지 않습니다.
- 링크 인증 정보나 쿠키가 필요한 스트림은 TV가 직접 접근하지 못할 수 있습니다. DRM을 우회하지 않습니다.
- 네트워크 AP/client isolation이 켜져 있으면 기기 검색이 실패할 수 있습니다.


## APK 빌드
1. Android Studio (Hedgehog 이상 권장)에서 이 폴더를 엽니다.
2. Android SDK Platform 35 및 Android SDK Build-Tools를 설치합니다.
3. Gradle Sync 후 `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 선택합니다.
4. APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.

이 프로젝트의 현재 버전은 디버그 APK용 소스입니다. 실제 TV/기기별 호환성은 실기기 테스트가 필요합니다.
