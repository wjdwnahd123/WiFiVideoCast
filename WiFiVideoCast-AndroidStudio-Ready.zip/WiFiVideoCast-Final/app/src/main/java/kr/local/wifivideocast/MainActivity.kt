package kr.local.wifivideocast

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastButtonFactory
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var status: TextView
    private lateinit var mediaBox: LinearLayout
    private val candidates = linkedSetOf<String>()
    private var selectedUrl: String? = null
    private var selectedDlna: DlnaDevice? = null
    private var dlnaDevices: List<DlnaDevice> = emptyList()
    private lateinit var dlna: DlnaClient

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dlna = DlnaClient(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val addressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        urlBox = EditText(this).apply {
            hint = "영상 페이지 주소"
            singleLine = true
            setText(incomingUrl())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        addressRow.addView(urlBox)
        addressRow.addView(Button(this).apply { text = "열기"; setOnClickListener { loadAddress() } })

        status = TextView(this).apply { text = "같은 Wi-Fi에 연결하세요. 앱 안에서 영상을 열면 주소를 찾아봅니다."; setPadding(10, 8, 10, 8) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val find = Button(this).apply { text = "영상 찾기"; setOnClickListener { scanPage() } }
        val dlnaSearch = Button(this).apply { text = "TV 검색"; setOnClickListener { discoverDlna() } }
        val castButton = MediaRouteButton(this)
        controls.addView(find)
        controls.addView(dlnaSearch)
        controls.addView(castButton, LinearLayout.LayoutParams(64, 52))
        mediaBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val play = Button(this).apply { text = "선택한 영상 TV에서 재생"; setOnClickListener { playSelected() } }
        val pause = Button(this).apply { text = "일시정지"; setOnClickListener { controlDlna("pause") } }
        val stop = Button(this).apply { text = "중지"; setOnClickListener { controlDlna("stop") } }
        val mediaControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(play); addView(pause); addView(stop) }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            addJavascriptInterface(Bridge(), "VideoCastBridge")
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    candidates.clear(); mediaBox.removeAllViews()
                    status.text = "페이지 로드 중…"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = "영상 재생 후 '영상 찾기'를 눌러보세요."
                    injectScanner()
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = false
                override fun onLoadResource(view: WebView?, url: String?) {
                    if (url != null && looksLikeMedia(url)) addCandidate(url)
                }
            }
        }

        root.addView(addressRow)
        root.addView(status)
        root.addView(controls)
        root.addView(ScrollView(this).apply { addView(mediaBox) }, LinearLayout.LayoutParams(-1, 120))
        root.addView(mediaControls)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        try {
            CastContext.getSharedInstance(this)
            CastButtonFactory.setUpMediaRouteButton(applicationContext, castButton)
        } catch (e: Exception) {
            status.text = "Chromecast 초기화 실패: ${e.message}"
        }
        handleIncoming(intent)
    }

    private fun incomingUrl(): String = when (intent?.action) {
        Intent.ACTION_VIEW -> intent.dataString ?: ""
        Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { extractUrl(it) } ?: ""
        else -> ""
    }

    private fun handleIncoming(i: Intent?) {
        val incoming = when (i?.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { extractUrl(it) }
            else -> null
        }
        if (!incoming.isNullOrBlank()) {
            urlBox.setText(incoming)
            web.loadUrl(incoming)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun extractUrl(raw: String): String? =
        Regex("https?://\\S+").find(raw)?.value?.trimEnd(')', '.', ',')

    private fun loadAddress() {
        val value = urlBox.text.toString().trim()
        if (value.startsWith("http://") || value.startsWith("https://")) web.loadUrl(value)
        else status.text = "http:// 또는 https:// 주소를 입력하세요."
    }

    private fun injectScanner() {
        val js = """
            (function(){
              if(window.__wifiCastScanner) return;
              window.__wifiCastScanner=true;
              function report(u){try{if(u && /^https?:/i.test(u)) VideoCastBridge.found(String(u));}catch(e){}}
              function scan(){
                document.querySelectorAll('video,audio,source').forEach(function(v){
                  report(v.currentSrc || v.src || v.getAttribute('src'));
                });
                try { performance.getEntriesByType('resource').forEach(function(e) {
                  if(/\\.(mp4|m3u8|webm|m4v|mov)([?#]|$)/i.test(e.name)) report(e.name);
                }); } catch(e) {}
              }
              setInterval(scan,1800); document.addEventListener('play',scan,true); scan();
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun scanPage() {
        injectScanner()
        web.evaluateJavascript(
            "document.querySelectorAll('video,audio,source').forEach(v=>VideoCastBridge.found(v.currentSrc||v.src||v.getAttribute('src')));",
            null
        )
        status.text = "영상 주소 검색 중… DRM 또는 보호된 스트림은 추출하지 않습니다."
    }

    inner class Bridge {
        @JavascriptInterface fun found(value: String) {
            runOnUiThread { addCandidate(value) }
        }
    }

    private fun looksLikeMedia(value: String): Boolean =
        value.startsWith("http") && listOf(".mp4", ".m3u8", ".webm", ".m4v", ".mov")
            .any { value.contains(it, true) }

    private fun addCandidate(value: String) {
        if (!looksLikeMedia(value) || !candidates.add(value)) return
        val radio = RadioButton(this).apply {
            text = value.take(105)
            setOnClickListener { selectedUrl = value; status.text = "선택한 미디어 주소가 변경됐습니다." }
        }
        mediaBox.addView(radio)
        if (selectedUrl == null) { selectedUrl = value; radio.isChecked = true }
        status.text = "미디어 주소 ${candidates.size}개 발견"
    }

    private fun discoverDlna() {
        status.text = "DLNA TV 검색 중…"
        scope.launch {
            try {
                dlnaDevices = withContext(Dispatchers.IO) { dlna.discover() }
                if (dlnaDevices.isEmpty()) status.text = "DLNA TV를 찾지 못했습니다. Chromecast 버튼도 시도해보세요."
                else {
                    val names = dlnaDevices.map { it.name }.toTypedArray()
                    val dialog = android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("TV 선택").setItems(names) { _, which ->
                            selectedDlna = dlnaDevices[which]
                            status.text = "${selectedDlna?.name} 선택됨"
                        }.create()
                    dialog.show()
                    status.text = "${dlnaDevices.size}개 DLNA 기기를 찾았습니다."
                }
            } catch (e: Exception) { status.text = "검색 실패: ${e.message}" }
        }
    }

    private fun playSelected() {
        val url = selectedUrl
        if (url.isNullOrBlank()) {
            status.text = "먼저 앱 안 브라우저에서 영상을 재생하고 영상 찾기를 누르세요."
            return
        }
        val dlnaDevice = selectedDlna
        if (dlnaDevice != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { dlna.play(dlnaDevice, url, "Wi-Fi Video Cast") }
                    status.text = "${dlnaDevice.name}에 DLNA 재생 요청을 보냈습니다."
                } catch (e: Exception) { status.text = "DLNA 재생 실패: ${e.message}" }
            }
            return
        }
        castSelected(url)
    }

    private fun castSelected(url: String) {
        try {
            val client = CastContext.getSharedInstance(this).sessionManager.currentCastSession?.remoteMediaClient
            if (client == null) { status.text = "먼저 Chromecast 버튼으로 TV에 연결하세요."; return }
            val mime = when {
                url.contains(".m3u8", true) -> "application/x-mpegURL"
                url.contains(".webm", true) -> "video/webm"
                else -> "video/mp4"
            }
            val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
                putString(MediaMetadata.KEY_TITLE, "Wi-Fi Video Cast")
            }
            val info = MediaInfo.Builder(url).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(mime).setMetadata(metadata).build()
            client.load(info, true)
            status.text = "TV에 재생 요청을 보냈습니다. TV가 직접 영상을 재생합니다."
        } catch (e: Exception) { status.text = "Chromecast 오류: ${e.message}" }
    }

    private fun controlDlna(action: String) {
        val device = selectedDlna ?: run { status.text = "DLNA TV를 먼저 선택하세요."; return }
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    if (action == "pause") dlna.pause(device) else dlna.stop(device)
                }
                status.text = if (action == "pause") "일시정지 요청 완료" else "중지 요청 완료"
            } catch (e: Exception) { status.text = "제어 실패: ${e.message}" }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        web.destroy()
        super.onDestroy()
    }
}
